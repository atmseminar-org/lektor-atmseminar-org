# ATRDS 2027 LaTeX paper template — version 2

Open `ATRDS2027.tex` as the main document. `IEEEtran.cls` is the supplied, unchanged class. `ATRDS2027.pdf` is the compiled example.

## Compile

- For **Times New Roman**, use XeLaTeX (or LuaLaTeX) on a system where the actual font is installed. The source selects it automatically. If not installed, it uses Tinos or Liberation Serif, with a warning. The supplied example was built with pdfLaTeX using the IEEEtran Times-compatible font (Nimbus Roman). No proprietary fonts are distributed.
- For standard pdfLaTeX, run `latexmk -pdf ATRDS2027.tex`. For XeLaTeX, run `latexmk -xelatex ATRDS2027.tex`. Both engines were tested. Run LaTeX twice if compiling manually.
- The template remains A4 and retains its existing LaTeX page geometry. The Word source is A4, but the supplied Word PDF was exported on US Letter and scaled; consequently pagination and line wrapping need not match exactly.

## Changes

- First-page conference line uses `(ATRDS 2027)` with a space; no page number on page 1. Automatic centered top page numbers beginning at 2, 10 pt.
- Figures: `Figure 1.` followed by the caption text, 8 pt; place `\caption` after the graphic. Tables: `TABLE I.` followed by uppercase caption text, 8 pt; place `\caption` before the table. In-text figure references continue to use `Fig. 1` as prescribed by the Word template.
- References: one unnumbered heading, bracketed numbers, hanging indents, 8 pt type, 9 pt leading and 2.5 pt spacing after each entry. Example citations follow their first-appearance order. For BibTeX, replace the example `thebibliography` environment with `\bibliographystyle{IEEEtran}` and `\bibliography{references}`.
- Added a standalone, unnumbered `Use of Generative AI` section before `Acknowledgment`. The wording asks for tools, purpose, affected parts, verification, author responsibility, and explicit disclosure of no use. It distinguishes manuscript assistance from research-method use. Authors should replace the instructions with their own truthful disclosure.
- Fixed duplicated affiliation placeholder, contradictory pagination instructions, caption cross-reference placement and balanced the final page.

The AI disclosure wording is proposed for ATRDS; IEEE's conference submission policy is a useful comparison (not a claim that ATRDS is governed by IEEE policy): https://conferences.ieeeauthorcenter.ieee.org/author-ethics/guidelines-and-policies/submission-policies/ . IEEE recommends disclosure of grammar/editing assistance and requires disclosure of generated material in its own publications. ATRDS may choose a more comprehensive disclosure rule.
